# Cassandra
Running terraform script and ansible script through Jenkins to create Cassandra Cluster
